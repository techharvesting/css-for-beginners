# The basics of HTML
The Playlist on the basics of HTML

### In this playlist, we discuss about the basics of html and how we can make a website using HTML

#### You can view the playlist here: [youtube.com/playlist?list=PL1djMrbwfVoXYV04viEODyt_e-aV96Eql](http://youtube.com/playlist?list=PL1djMrbwfVoXYV04viEODyt_e-aV96Eql)



#### Make sure you choose the correct branch to see the code.
